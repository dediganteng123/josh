Author:https://t.me/cyzexploit


Important: We Never selling this tools,this is a free Tools!!!

[=] Install python 2 (Make Folder python2 like this = C:\python27) https://www.python.org/downloads/release/python-2714/

[=] How to run:

-1 Run cmd as Administrator,then run crack.py command like (C:\python27\python crack.py)
-2 if crack.py running without trouble, open cmd then run ExV2.py (C:\python27\python ExV2.py)
-3 using cyzarine as username and password for ExV2.py or ExV2P.py then enter
-4 Done

Note : You can Close crack.py after success run ExV2.py or ExV2P.py and need repeat from number 1 if you wanna using back ExV2.py or ExV2P.py

We not responsible for any acts of sabotage that may occur due to misuse.